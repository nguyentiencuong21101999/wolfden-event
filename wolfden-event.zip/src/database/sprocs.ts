export const Sprocs = {
    /** USER */

    /** usp_User_getDetail(userId) */
    UserGetProfile: 'usp_User_getDetail',
}
