export class EventScanService {}
